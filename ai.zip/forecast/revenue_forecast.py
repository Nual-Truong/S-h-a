import pandas as pd
from sklearn.linear_model import LinearRegression
from db.database import get_connection


def _load_monthly_revenue():
    with get_connection() as conn:
        df = pd.read_sql("SELECT date, amount FROM transactions", conn)

    df["date"] = pd.to_datetime(df["date"])
    df["month"] = df["date"].dt.to_period("M")

    monthly = df.groupby("month")["amount"].sum().reset_index()
    monthly["month_num"] = range(len(monthly))
    return monthly


def forecast_next_month():
    monthly = _load_monthly_revenue()

    if len(monthly) < 2:
        return 0

    model = LinearRegression()
    model.fit(monthly[["month_num"]], monthly["amount"])

    next_month = pd.DataFrame({"month_num": [len(monthly)]})
    forecast = model.predict(next_month)[0]

    return int(forecast)


def evaluate_forecast():
    monthly = _load_monthly_revenue()

    if len(monthly) < 3:
        return {"mae": None, "mape": None, "samples": len(monthly)}

    model = LinearRegression()
    model.fit(monthly[["month_num"]], monthly["amount"])
    predicted = model.predict(monthly[["month_num"]])

    actual = monthly["amount"].astype(float)
    abs_error = (actual - predicted).abs()
    mae = float(abs_error.mean())

    non_zero = actual != 0
    if non_zero.any():
        mape = float((abs_error[non_zero] / actual[non_zero]).mean() * 100)
    else:
        mape = None

    return {
        "mae": mae,
        "mape": mape,
        "samples": len(monthly),
    }


def forecast_by_category():
    with get_connection() as conn:
        df = pd.read_sql("SELECT date, category, amount FROM transactions", conn)

    df["date"] = pd.to_datetime(df["date"])
    df["month"] = df["date"].dt.to_period("M")

    results = []

    for category in df["category"].unique():
        sub = df[df["category"] == category]
        monthly = sub.groupby("month")["amount"].sum().reset_index()
        monthly["month_num"] = range(len(monthly))

        if len(monthly) < 2:
            continue

        model = LinearRegression()
        model.fit(monthly[["month_num"]], monthly["amount"])

        next_month = pd.DataFrame({"month_num": [len(monthly)]})
        forecast = model.predict(next_month)[0]

        results.append((category, int(forecast)))

    return pd.DataFrame(results, columns=["Category", "Forecast"])
