import streamlit as st
import pandas as pd
from db.database import get_connection
from forecast.revenue_forecast import evaluate_forecast, forecast_next_month
from ai.trend_analysis import analyze_trend
from ai.anomaly_detection import detect_anomalies
from blockchain.ledger import (
    get_recent_audit_logs,
    tamper_random_transaction,
    verify_ledger,
)
from sklearn.ensemble import IsolationForest

st.title("Quản Lý Tài Chính Thông Minh")

# ======================
# LOAD DATA
# ======================
conn = get_connection()
df = pd.read_sql("SELECT * FROM transactions", conn)
conn.close()

# ======================
# BASIC METRICS
# ======================
st.metric("Tổng doanh thu", int(df["amount"].sum()))
st.metric("Tổng chi phí", int(df["cost"].sum()))
st.metric("Tổng lợi nhuận", int(df["profit"].sum()))

# ======================
# REVENUE CHART
# ======================
import altair as alt

st.subheader("📊 Hiển thị dữ liệu doanh thu tháng tới qua AI")

# TẠO chart_data trước khi dùng
chart_data = df.groupby("date")["amount"].sum().reset_index()

chart = alt.Chart(chart_data).mark_line(point=True).encode(
    x="date:T",
    y="amount:Q"
).interactive()

st.altair_chart(chart, width="stretch")

# ======================
# FORECAST
# ======================
forecast = forecast_next_month()
st.subheader("Dự báo doanh thu tháng tới")
st.success(f"{int(forecast)} VND")

# ======================
# ANOMALY DETECTION (AI)
# ======================
model = IsolationForest(contamination=0.05)
df["anomaly"] = model.fit_predict(df[["amount","cost","profit"]])
anomaly_count = df[df["anomaly"] == -1].shape[0]

st.metric("Phát hiện bất thường", anomaly_count)

# ======================
# TREND ANALYSIS
# ======================
st.subheader("Phân tích xu hướng tiêu dùng")
trend_df = analyze_trend()
st.dataframe(
    trend_df.rename(
        columns={
            "date": "Tháng",
            "category": "Danh mục",
            "amount": "Doanh thu",
        }
    ),
    width="stretch",
)

# ======================
# RISK ALERT
# ======================
st.subheader("Cảnh báo rủi ro tài chính")
anomalies = detect_anomalies()

if anomalies.empty:
    st.success("Không phát hiện rủi ro tài chính")
else:
    st.warning(f"{len(anomalies)} Phát hiện giao dịch đáng ngờ")
    st.dataframe(
        anomalies.rename(
            columns={
                "date": "Ngày",
                "category": "Danh mục",
                "amount": "Doanh thu",
                "cost": "Chi phí",
                "profit": "Lợi nhuận",
                "anomaly": "Nhãn bất thường",
            }
        ),
        width="stretch",
    )

from forecast.revenue_forecast import forecast_by_category

st.subheader("🔮 Dự báo theo danh mục")
forecast_df = forecast_by_category()
st.dataframe(
    forecast_df.sort_values(by="Forecast", ascending=False).rename(
        columns={"Category": "Danh mục", "Forecast": "Dự báo doanh thu"}
    ),
    width="stretch",
)

forecast_eval = evaluate_forecast()
st.caption("Đánh giá chất lượng mô hình dự báo")
if forecast_eval["mae"] is None or forecast_eval["mape"] is None:
    st.info("Chưa đủ dữ liệu để tính MAE/MAPE (cần ít nhất 3 mốc tháng và doanh thu khác 0).")
else:
    col1, col2 = st.columns(2)
    col1.metric("MAE", f"{forecast_eval['mae']:.2f}")
    col2.metric("MAPE", f"{forecast_eval['mape']:.2f}%")

from ai.insight_generator import generate_insight

st.subheader("🤖 Thông tin tài chính từ AI")
st.info(generate_insight())

from ai.seasonality import analyze_seasonality

st.subheader("📈 Phân tích tính chu kỳ/mùa vụ")
season_df = analyze_seasonality()
st.bar_chart(season_df.set_index("month"))

# ======================
# BLOCKCHAIN INTEGRITY CHECK
# ======================
st.subheader("Toàn vẹn dữ liệu Blockchain")
with get_connection() as integrity_conn:
    integrity_result = verify_ledger(integrity_conn, auto_rebuild=True)
    audit_df = get_recent_audit_logs(integrity_conn, limit=8)

latest_hash = integrity_result["latest_hash"]
short_hash = "N/A"
if latest_hash:
    short_hash = f"{latest_hash[:12]}...{latest_hash[-12:]}"

if integrity_result["valid"]:
    st.success("Sổ cái hợp lệ. Dữ liệu tài chính đã được bảo vệ khỏi chỉnh sửa ngầm.")
    if integrity_result["issues"]:
        st.info(integrity_result["issues"][0])
else:
    st.error("Xác minh sổ cái thất bại.")
    preview_issues = integrity_result["issues"][:3]
    for issue in preview_issues:
        st.write(f"- {issue}")
    if len(integrity_result["issues"]) > 3:
        st.caption(f"... và {len(integrity_result['issues']) - 3} lỗi khác")

st.caption(f"Số khối: {integrity_result['blocks']}")
st.caption(f"Hash mới nhất: {short_hash}")

with st.expander("Xem chi tiết blockchain"):
    st.write(f"Hash đầy đủ: {latest_hash}")
    if integrity_result["issues"]:
        st.write("Danh sách chi tiết vấn đề:")
        for issue in integrity_result["issues"]:
            st.write(f"- {issue}")

status_map = {"PASSED": "THÀNH CÔNG", "FAILED": "THẤT BẠI"}
audit_display = audit_df.copy()
if not audit_display.empty:
    audit_display["status"] = audit_display["status"].map(status_map).fillna(audit_display["status"])

st.caption("Lịch sử xác minh blockchain gần nhất")
st.dataframe(
    audit_display.rename(
        columns={
            "checked_at": "Thời gian",
            "status": "Trạng thái",
            "blocks": "Số khối",
            "latest_hash": "Hash mới nhất",
            "issue_count": "Số lỗi",
            "issue_preview": "Tóm tắt lỗi",
        }
    ),
    width="stretch",
)

st.divider()
st.subheader("Kiểm thử giả lập chỉnh sửa (Demo)")
st.caption("Chỉ dùng để demo. Chức năng này sẽ cố ý sửa một bản ghi.")

if st.button("Giả lập sửa ngẫu nhiên 1 giao dịch"):
    with get_connection() as tamper_conn:
        tamper_info = tamper_random_transaction(tamper_conn)

    if tamper_info is None:
        st.warning("Không tìm thấy giao dịch để giả lập chỉnh sửa.")
    else:
        st.warning(
            f"Đã chỉnh sửa dòng {tamper_info['rowid']}: số tiền {tamper_info['old_amount']} -> {tamper_info['new_amount']}"
        )
        st.info("Làm mới trang để thấy trạng thái xác minh blockchain chuyển sang THẤT BẠI.")