import sqlite3

DB_PATH = "data/sfm.db"

def get_connection():
    return sqlite3.connect(DB_PATH)