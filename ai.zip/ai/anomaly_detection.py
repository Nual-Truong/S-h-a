import pandas as pd
from sklearn.ensemble import IsolationForest
from db.database import get_connection

def detect_anomalies():
    conn = get_connection()
    df = pd.read_sql("SELECT * FROM transactions", conn)
    conn.close()

    model = IsolationForest(contamination=0.05, random_state=42)
    df["anomaly"] = model.fit_predict(df[["amount","cost","profit"]])

    anomalies = df[df["anomaly"] == -1]

    return anomalies