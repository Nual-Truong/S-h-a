import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

np.random.seed(42)

start_date = datetime(2023, 1, 1)
end_date = datetime(2024, 12, 31)

dates = pd.date_range(start_date, end_date, freq="D")

categories = ["Electronics", "Food", "Clothing", "Services", "Healthcare"]

data = []

for date in dates:
    for _ in range(random.randint(2, 5)):  # 2-5 transactions per day
        
        category = random.choice(categories)
        
        # Trend tăng dần theo thời gian
        trend_factor = (date.year - 2023) * 20000 + date.month * 2000
        
        # Seasonality
        if date.month == 12:
            season_factor = 50000
        elif date.month == 2:
            season_factor = -20000
        else:
            season_factor = 0
        
        base_amount = random.randint(50000, 200000)
        amount = base_amount + trend_factor + season_factor
        
        cost = amount * random.uniform(0.6, 0.85)
        profit = amount - cost
        
        data.append([
            date.strftime("%Y-%m-%d"),
            category,
            int(amount),
            int(cost),
            int(profit)
        ])

# Thêm 5 giao dịch bất thường
for _ in range(5):
    data.append([
        "2024-11-15",
        "Electronics",
        5000000,
        100000,
        4900000
    ])

df = pd.DataFrame(data, columns=["date", "category", "amount", "cost", "profit"])

df.to_csv("data/transactions.csv", index=False)

print("Dataset generated successfully!")