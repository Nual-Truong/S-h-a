from db.database import get_connection
from blockchain.ledger import verify_ledger


def main():
    with get_connection() as conn:
        result = verify_ledger(conn)

    if result["valid"]:
        print("Blockchain integrity check: PASSED")
    else:
        print("Blockchain integrity check: FAILED")
        for issue in result["issues"]:
            print(f"- {issue}")

    print(f"Blocks: {result['blocks']}")
    print(f"Latest hash: {result['latest_hash']}")


if __name__ == "__main__":
    main()
