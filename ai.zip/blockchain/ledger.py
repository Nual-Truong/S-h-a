import hashlib
import json
from datetime import datetime, timezone

import pandas as pd

LEDGER_TABLE = "transaction_ledger"
AUDIT_TABLE = "ledger_audit_log"


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _normalize_record(row: pd.Series) -> str:
    payload = {
        "date": str(row["date"]),
        "category": str(row["category"]),
        "amount": int(row["amount"]),
        "cost": int(row["cost"]),
        "profit": int(row["profit"]),
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _build_expected_chain(df: pd.DataFrame):
    ordered_df = (
        df[["date", "category", "amount", "cost", "profit"]]
        .copy()
        .sort_values(["date", "category", "amount", "cost", "profit"])
        .reset_index(drop=True)
    )

    expected = []
    prev_hash = "0" * 64

    for block_index, row in ordered_df.iterrows():
        data_hash = _sha256(_normalize_record(row))
        block_payload = f"{block_index}|{data_hash}|{prev_hash}"
        block_hash = _sha256(block_payload)
        expected.append((block_index, data_hash, prev_hash, block_hash))
        prev_hash = block_hash

    return expected


def _ensure_ledger_table(conn):
    conn.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {LEDGER_TABLE} (
            block_index INTEGER PRIMARY KEY,
            data_hash TEXT NOT NULL,
            prev_hash TEXT NOT NULL,
            block_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )


def _ensure_audit_table(conn):
    conn.execute(
        f"""
        CREATE TABLE IF NOT EXISTS {AUDIT_TABLE} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            checked_at TEXT NOT NULL,
            status TEXT NOT NULL,
            blocks INTEGER NOT NULL,
            latest_hash TEXT,
            issue_count INTEGER NOT NULL,
            issue_preview TEXT
        )
        """
    )


def _save_audit(conn, result):
    checked_at = datetime.now(timezone.utc).isoformat()
    status = "PASSED" if result["valid"] else "FAILED"
    issue_count = len(result["issues"])
    issue_preview = "; ".join(result["issues"][:3]) if result["issues"] else ""

    conn.execute(
        f"""
        INSERT INTO {AUDIT_TABLE}
        (checked_at, status, blocks, latest_hash, issue_count, issue_preview)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            checked_at,
            status,
            int(result["blocks"]),
            result["latest_hash"],
            issue_count,
            issue_preview,
        ),
    )
    conn.commit()


def get_recent_audit_logs(conn, limit=10):
    _ensure_audit_table(conn)
    return pd.read_sql(
        f"""
        SELECT checked_at, status, blocks, latest_hash, issue_count, issue_preview
        FROM {AUDIT_TABLE}
        ORDER BY id DESC
        LIMIT ?
        """,
        conn,
        params=(int(limit),),
    )


def rebuild_ledger(conn, df: pd.DataFrame):
    _ensure_ledger_table(conn)
    expected_chain = _build_expected_chain(df)

    conn.execute(f"DELETE FROM {LEDGER_TABLE}")

    created_at = datetime.now(timezone.utc).isoformat()
    records = [
        (block_index, data_hash, prev_hash, block_hash, created_at)
        for block_index, data_hash, prev_hash, block_hash in expected_chain
    ]

    if records:
        conn.executemany(
            f"""
            INSERT INTO {LEDGER_TABLE}
            (block_index, data_hash, prev_hash, block_hash, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            records,
        )

    latest_hash = records[-1][3] if records else None
    return {"blocks": len(records), "latest_hash": latest_hash}


def verify_ledger(conn, auto_rebuild=False):
    _ensure_ledger_table(conn)
    _ensure_audit_table(conn)

    def _finalize(result):
        _save_audit(conn, result)
        return result

    issues = []

    try:
        tx_df = pd.read_sql(
            "SELECT date, category, amount, cost, profit FROM transactions",
            conn,
        )
    except Exception as exc:
        return _finalize({
            "valid": False,
            "issues": [f"Không thể truy cập bảng transactions: {exc}"],
            "blocks": 0,
            "latest_hash": None,
        })

    ledger_df = pd.read_sql(
        f"""
        SELECT block_index, data_hash, prev_hash, block_hash
        FROM {LEDGER_TABLE}
        ORDER BY block_index
        """,
        conn,
    )

    expected_chain = _build_expected_chain(tx_df)

    if auto_rebuild and expected_chain and ledger_df.empty:
        rebuilt = rebuild_ledger(conn, tx_df)
        return _finalize({
            "valid": True,
            "issues": ["Sổ cái trống và đã được tạo lại tự động."],
            "blocks": rebuilt["blocks"],
            "latest_hash": rebuilt["latest_hash"],
        })

    if len(expected_chain) != len(ledger_df):
        issues.append(
            "Số lượng khối không khớp giữa bảng giao dịch và sổ cái blockchain."
        )

    comparison_len = min(len(expected_chain), len(ledger_df))

    for i in range(comparison_len):
        exp_idx, exp_data_hash, exp_prev_hash, exp_block_hash = expected_chain[i]
        row = ledger_df.iloc[i]

        if int(row["block_index"]) != exp_idx:
            issues.append(f"Chỉ số khối không hợp lệ tại vị trí {i}.")
        if row["data_hash"] != exp_data_hash:
            issues.append(f"Data hash không khớp tại khối {exp_idx}.")
        if row["prev_hash"] != exp_prev_hash:
            issues.append(f"Previous hash không khớp tại khối {exp_idx}.")
        if row["block_hash"] != exp_block_hash:
            issues.append(f"Block hash không khớp tại khối {exp_idx}.")

    latest_hash = None
    if not ledger_df.empty:
        latest_hash = str(ledger_df.iloc[-1]["block_hash"])

    return _finalize({
        "valid": len(issues) == 0,
        "issues": issues,
        "blocks": len(ledger_df),
        "latest_hash": latest_hash,
    })


def tamper_random_transaction(conn, amount_delta=999):
    cursor = conn.execute(
        "SELECT rowid, amount, cost FROM transactions ORDER BY RANDOM() LIMIT 1"
    )
    row = cursor.fetchone()

    if not row:
        return None

    rowid, amount, cost = int(row[0]), int(row[1]), int(row[2])
    new_amount = amount + int(amount_delta)
    new_profit = new_amount - cost

    conn.execute(
        "UPDATE transactions SET amount = ?, profit = ? WHERE rowid = ?",
        (new_amount, new_profit, rowid),
    )
    conn.commit()

    return {
        "rowid": rowid,
        "old_amount": amount,
        "new_amount": new_amount,
    }
